int a = 6;
int b;
void main() {
    int d;
    d = a + 6;
    print(d);

    return;
}

