void main(){
    int a = 1;
    while (a < 6){
        print(a);
        a++;
    }
    return;
}

